refershTrainingDataGenControl(client);


    var http2 = new Http();


    http2.setVantiqUrlForResource("TrainingDataGenConfig");

    //
    //  Add the Authorization header to the request
    //
    http2.setVantiqHeaders();

	args = {};
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  resourceId: The "_id" of the object being loaded
    //  parameters: "null" or an object containing the parameters for this request
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http2.select(args,function(response)
    {
        //
        //  At this point "response" is the object found
        //
        if (response.length === 0)
            {
            	client.getCurrentPage().data.TDConfigid = -1;
				client.getCurrentPage().data.TrainingDataGenConfig.initializeToDefaultValues();
            }
        else
            {
                console.log("SUCCESS: " + JSON.stringify(response));
                client.getCurrentPage().data.TrainingDataGenConfig = response[0];
                client.getCurrentPage().data.TDConfigid = response[0]._id;
                console.log("SUCCESS: " + JSON.stringify(client.getCurrentPage().data.TDConfigid));
            }
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing a select on a single'Employee'");
    });
