var msg = {};
msg.Topic = data.message.topic;
msg.Message = JSON.stringify(data.message.data);
client.sendClientEvent("PublishMessageClientStream", msg);
client.data.LastMessageData = JSON.stringify(data.message.data,null,2);
Binding.applyChanges();