client.getWidget("ImageViewer1").url = data.file_URI;
client.data.JsonData = JSON.stringify(data, null, 4);