    //***
    //*** The following code fragment demonstrates how to select one or more records of a user Type.
    //*** You must edit it to make it match the detailed situation for your Client.
    //***
    
    //
    //  Create an instance of the Http class to execute our server request
    //
    var http = new Http();
    
    //
    //  Build the URL needed to do a "select" on the specified user Type
    //
    http.setVantiqUrlForResource("guards");
    
    //
    //  Add the Authorization header to the request
    //
    http.setVantiqHeaders();
    
    //
    //  Specify the (optional) query parameters
    //
    var guardId = extra.guard_id;
    var parameters = {
        where: {"guard_id": guardId}
    };
    
    //
    //  Execute the asynchronous server request. This expects 3 parameters:
    //
    //  parameters: "null" or an object containing the parameters for this request
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http.select(parameters,function(response)
    {
        //
        //  At this point "response" is an array containing the objects returned for the "select".
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        client.data.guards = response[0];
 
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing a select on 'Employee'");
    });