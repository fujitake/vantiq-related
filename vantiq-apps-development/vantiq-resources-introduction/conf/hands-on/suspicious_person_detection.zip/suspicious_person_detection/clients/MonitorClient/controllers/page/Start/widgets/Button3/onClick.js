    //***
    //*** This code fragment demonstrates how to upsert (update or insert) a single record.
    //*** You must edit it to make it match the detailed situation for your Client.
    //***
    
    //
    //  Create an instance of the Http class to execute our server request
    //
    var http = new Http();
    
    //
    //  Build the URL needed to do an "update" on our Type
    //
    http.setVantiqUrlForResource("guards");
    
    //
    //  Add the Authorization header to the request
    //
    http.setVantiqHeaders();

    //
    //  A variable which contains the object to be inserted or updated. 
    //
    //  Important! This Type *must* have a naturalKey declared, and the value of the naturalKey must
    //  appear in this object.
    //
    var guards = client.data.guards;
    
    //
    //  Execute the asynchronous server request. This expects 3 parameters:
    //
    //  data: The object being inserted or updated.
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http.upsert(guards,function(response)
    {
        //
        //  At this point "response" is the updated object
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        
        var ds = client.getDataStreamByName("GuardInfoQuery");
    	ds.restart();
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing an upsert of an Employee");
    });    
    //*** End of fragment