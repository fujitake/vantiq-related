mapWidget = client.getWidget("DynamicMapViewer1");
map = mapWidget.map;
var min = new google.maps.LatLng(35.687, 139.764);
var max = new google.maps.LatLng(35.689, 139.766);
map.fitBounds(new google.maps.LatLngBounds(min, max));