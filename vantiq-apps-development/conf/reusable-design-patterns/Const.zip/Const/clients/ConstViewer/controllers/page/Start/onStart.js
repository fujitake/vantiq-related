
    client.data.SelectedType = "String";
    client.getWidget("InputReal1").isReadOnly = true;
    client.getWidget("InputInteger1").isReadOnly = true;
    client.getWidget("InputString3").isReadOnly = false;
    client.data.Const.integerValue = null;
    client.data.Const.numberValue = null;
    
   	//***
    //*** This code fragment demonstrates how to execute a Procedure on the server.
    //*** You must edit it to make it match the detailed situation for your Client.
    //***
    
    //
    //  Set the Procedure arguments by name. (You may also specify 'args' as an array where the
    //  parameters are given in the same order as in the Procedure definition (e.g. 'args = [10,20];').
    //  'args' must not be null.
    //
    var args = {
    };
    
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  procedureArguments: The procedure arguments.
    //  procedureName:      The fully-qualified name of the Procedure.
    //  successCallback:    A callback function that will be driven when the request completes
    //                      successfully (i.e. a status code of 2XX)
    //  failureCallback:    A callback function that will be driven when the request does not complete
    //                      successfully.
    //
    client.execute(args,"jp.co.vantiq.designpattern.Const.viewConstState",function(response)
    {
        //
        //  At this point "response" is results of the Procedure call
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        
        client.data.ConstState = JSON.stringify(response, null, 4);
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Executing 'MyService.MyProcedure'");
    });
    //*** End of fragment