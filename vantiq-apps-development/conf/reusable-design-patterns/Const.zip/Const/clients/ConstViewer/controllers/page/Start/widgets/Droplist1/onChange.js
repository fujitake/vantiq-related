	var selectedType = client.data.SelectedType;
    
    if ( selectedType == "String") {
        
        client.getWidget("InputReal1").isReadOnly = true;
        client.getWidget("InputReal1").boundValue = null;
        client.getWidget("InputInteger1").isReadOnly = true;
        client.getWidget("InputInteger1").boundValue = null;
   		client.getWidget("InputString3").isReadOnly = false;
        
    }
    
     else if ( selectedType == "Integer") {
        
        client.getWidget("InputReal1").isReadOnly = true;
        client.getWidget("InputReal1").boundValue = null;
        client.getWidget("InputInteger1").isReadOnly = false;
   		client.getWidget("InputString3").isReadOnly = true;
        client.getWidget("InputString3").boundValue = null;
        
    }
    
    else {
        client.getWidget("InputReal1").isReadOnly = false;
        client.getWidget("InputInteger1").isReadOnly = false;
        client.getWidget("InputInteger1").boundValue = null;
   		client.getWidget("InputString3").isReadOnly = true;
        client.getWidget("InputString3").boundValue = null;
    }