
    //***
    //*** This code fragment demonstrates how to insert a record of a user Type.
    //*** You must edit it to make it match the detailed situation for your Client.
    //***
    
    //
    //  The object to be inserted
    //
    var aNewConst = client.data.Const;
    var selectedType = client.data.SelectedType;
    
    if ( selectedType == "String") {
        
        aNewConst.integerValue = null;
        aNewConst.numberValue = null;
    }
    
     else if ( selectedType == "Integer") {
        
        aNewConst.stringValue = null;
        aNewConst.numberValue = null;
    }
    
    else {
        aNewConst.integerValue = null;
        aNewConst.stringValue = null;
   }
        
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  typeName:        The Type where the record is to be inserted.
    //  data:            The object being inserted.
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    client.upsert("jp.co.vantiq.designpattern.Const",aNewConst,function(response)
    {
        //
        //  At this point "response" is the inserted object
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        
        
        client.data.SelectedType = "String";
        client.getWidget("InputReal1").isReadOnly = true;
        client.getWidget("InputInteger1").isReadOnly = true;
   		client.getWidget("InputString3").isReadOnly = false;
    	client.data.Const.key = null;
    	client.data.Const.stringValue = null;
    	client.data.Const.integerValue = null;
    	client.data.Const.numberValue = null;
        client.data.Const.remark = null;

        
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing an insert of a new Employee");
    });
    //*** End of fragment
