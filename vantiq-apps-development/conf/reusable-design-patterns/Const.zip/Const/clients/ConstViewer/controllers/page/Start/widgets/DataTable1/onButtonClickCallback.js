	var constRec = extra.dataObject;
    client.data.Const = {
        stringValue : null,
        integerValue : null,
        numberValue : null,
        remark : null
    };
    
    if (constRec.stringValue) {
        client.data.SelectedType = "String";
        client.data.Const = constRec;
        client.getWidget("InputReal1").isReadOnly = true;
        client.getWidget("InputInteger1").isReadOnly = true;
   		client.getWidget("InputString3").isReadOnly = false;

    } else if (constRec.integerValue) {
        client.data.SelectedType = "Integer";
        client.data.Const = constRec;        
        client.getWidget("InputReal1").isReadOnly = true;
        client.getWidget("InputInteger1").isReadOnly = false;
   		client.getWidget("InputString3").isReadOnly = true;

    } else {
        client.data.SelectedType = "Real";
        client.data.Const = constRec;                
        client.getWidget("InputReal1").isReadOnly = false;
        client.getWidget("InputInteger1").isReadOnly = true;
   		client.getWidget("InputString3").isReadOnly = true;
    }
