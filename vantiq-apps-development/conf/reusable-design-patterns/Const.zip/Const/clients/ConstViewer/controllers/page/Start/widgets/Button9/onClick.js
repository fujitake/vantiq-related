	
    var constKey = client.data.Const.key;
        
    //***
    //*** The following code fragment demonstrates how to select one or more records of a user Type.
    //*** You must edit it to make it match the detailed situation for your Client.
    //***
    
    //
    //  Specify the (optional) query parameters
    //
    var parameters = {
        where: {key: constKey}
    };
    
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  typeName:        The Type where the records will be found.
    //  parameters: "null" or an object containing the parameters for this request
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    client.select("jp.co.vantiq.designpattern.Const",parameters,function(response)
    {
        //
        //  At this point "response" is an array containing the objects returned for the "select".
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        
        
        //***
        //*** This code fragment demonstrates how to delete a single record of a user Type by _id.
        //*** You must edit it to make it match the detailed situation for your Client.
        //***

        //
        //  This _id was probably obtained by a previous "select".
        //
//        var theEmployeeId = "59776c4589133374df264357";
        
        if (response.length > 0) {
            var constId = response[0]["_id"];

            //
            //  Execute the asynchronous server request. This expects 5 parameters:
            //
            //  typeName:        The Type containing the record to be deleted.
            //  resourceId:      The "_id" of the object being deleted
            //  successCallback: A callback function that will be driven when the request completes
            //                   successfully (i.e. a status code of 2XX)
            //  failureCallback: A callback function that will be driven when the request does not complete
            //                   successfully.
            //
            client.deleteOne("jp.co.vantiq.designpattern.Const",constId,function(response)
                             {
                //
                //  The "response" object is meaningless in this case.
                //
                console.log("Delete Successful");
            },
                             function(errors)
                             {
                //
                //  This call will format the error into a popup dialog
                //
                client.showHttpErrors(errors,"Doing a delete on a single 'Employee'");
            });
            //*** End of fragment
          
        }

        
        
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing a select on 'Employee'");
    });
    //*** End of fragment
