function varDefined(v){ return (v !== null && v !== undefined);}
if(!varDefined(jp)) { var jp = {}; }
if(!varDefined(jp.co)) { jp.co = {}; }
if(!varDefined(jp.co.vantiq)) { jp.co.vantiq = {}; }
if(!varDefined(jp.co.vantiq.designpattern)) { jp.co.vantiq.designpattern = {}; }
if(!varDefined(jp.co.vantiq.designpattern.EchoPattern)) { jp.co.vantiq.designpattern.EchoPattern = {}; }
