//
    //  Create an instance of the Http class to execute our server request
    //
    var http = new Http();

    //
    //  Build the URL needed to do an "execute" of a Procedure
    //
    http.setVantiqUrlForSystemResource("procedures");

    //
    //  Add the Authorization header to the request
    //
    http.setVantiqHeaders();

    //
    //  Set the Procedure arguments
    //
    var args = {};

    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  procedureArguments: The procedure arguments.
    //  procedureName: The fully-qualified name of the Procedure.
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http.execute(args,"jp.co.vantiq.ws.datagen.CreateRPMScheduledEvents",function(response)
    {
        //
        //  At this point "response" is results of the Procedure call
        //
        console.log("SUCCESS: " + JSON.stringify(response));
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Executing 'CreateScheduledEvents'");
    });