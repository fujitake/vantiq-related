 //
    //  Create an instance of the Http class to execute our server request
    //
    var http = new Http();

    //
    //  Build the URL needed to do an "update" on our Type
    //
    http.setVantiqUrlForResource("jp.co.vantiq.ws.datagen.TrainingDataGenControl");

    //
    //  Add the Authorization header to the request
    //
    http.setVantiqHeaders();
	var updateData = {};
	updateData.Status = page.data.SelectedStatus;
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  data: The object being inserted.
    //  parameters: "null" or an object containing the parameters for this request
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http.update(updateData,page.data.SelectedPumpID,function(response)
    {
        //
        //  At this point "response" is the updated object
        //
        console.log("SUCCESS: " + JSON.stringify(response));
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing an update of an existing Employee");
    });