function refershTrainingDataGenControl(client)
{
    
    var http = new Http();


    http.setVantiqUrlForResource("jp.co.vantiq.ws.datagen.TrainingDataGenControl");

    //
    //  Add the Authorization header to the request
    //
    http.setVantiqHeaders();

	var args = {};
    //
    //  Execute the asynchronous server request. This expects 4 parameters:
    //
    //  resourceId: The "_id" of the object being loaded
    //  parameters: "null" or an object containing the parameters for this request
    //  successCallback: A callback function that will be driven when the request completes
    //                   successfully (i.e. a status code of 2XX)
    //  failureCallback: A callback function that will be driven when the request does not complete
    //                   successfully.
    //
    http.select(args,function(response)
    {
        //
        //  At this point "response" is the object found
        //
        console.log("SUCCESS: " + JSON.stringify(response));
        client.sendClientEvent("CurrentTrainingDataGenControlStream", response);
        
        var PumpDL = client.getWidget("PumpDroplist");
		var enumList = [];
        

        var arrayLength = response.length;
		if (arrayLength > 0)
            {
            	enumList.push({value:0, label: "Select a Pump"});
                for (var i = 0; i < arrayLength; i++)
                    {
                        enumList.push({value:response[i]._id, label: "Pump " + response[i].PumpNo});
                    }
            }
        else
			{
            	enumList.push({value:0, label: "No Pumps defined"});
        
            }

        PumpDL.enumeratedList = enumList;
        Binding.applyChanges();
    },
    function(errors)
    {
        //
        //  This call will format the error into a popup dialog
        //
        client.showHttpErrors(errors,"Doing a select on a single'TrainingDataGenControl'");
    });


}