    var http = new Http();
    http.setVantiqUrlForSystemResource("procedures");
    http.setVantiqHeaders();
    var args = {};
    http.execute(args,"GenerateWifiApData.createScheduledEvent",function(response){
         client.data.LastData = "..Data Generator is starting up. Please wait a moment.";
    },
    function(errors)
    {
        client.showHttpErrors(errors,"Executing 'GenerateWifiApData.createScheduledEvent'");
    });